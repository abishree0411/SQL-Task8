-- Use the stored procedure to get all HR employees
CALL FetchEmployeesByDepartment('HR');

-- Use the function to calculate tax for each employee
SELECT full_name, salary, CalculateTax(salary) AS tax_amount
FROM employees;
