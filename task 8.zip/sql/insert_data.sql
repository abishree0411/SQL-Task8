-- Insert example data into employees table
INSERT INTO employees (full_name, department, salary) VALUES
('Arjun Mehta', 'IT', 75000),
('Neha Sharma', 'HR', 62000),
('Rajiv Singh', 'Finance', 58000),
('Pooja Nair', 'IT', 82000),
('Karan Patel', 'HR', 61000);
