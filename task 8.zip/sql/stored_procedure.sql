-- Stored Procedure: Fetch all employees from a given department
DELIMITER //
CREATE PROCEDURE FetchEmployeesByDepartment(IN dept_name VARCHAR(50))
BEGIN
    SELECT emp_id, full_name, salary
    FROM employees
    WHERE department = dept_name;
END //
DELIMITER ;
