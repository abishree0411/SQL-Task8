-- Function: Compute tax deduction as 12% of salary
DELIMITER //
CREATE FUNCTION CalculateTax(sal DECIMAL(10,2))
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    RETURN sal * 0.12;
END //
DELIMITER ;
